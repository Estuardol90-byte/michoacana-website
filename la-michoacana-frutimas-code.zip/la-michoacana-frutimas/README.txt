LA MICHOACANA FRUTIMAS — POLISHED WEBSITE

Open index.html in a web browser to view the website.

Files included:
- index.html: page content
- styles.css: visual design and responsive layout
- script.js: mobile navigation
- assets/: optimized logo and original generated food photography

The website is fully static and can be uploaded to most website hosts as-is.
